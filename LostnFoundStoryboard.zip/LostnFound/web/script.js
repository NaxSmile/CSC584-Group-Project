// ============================================================
// 🔧 CONFIGURATION: Change these paths to your own images
// ============================================================
const imagePaths = {
    usecase: "images/usecase-diagram.jpeg",   // 👈 Replace with your Use Case diagram path
    erd: "images/erd-diagram.jpeg",           // 👈 Replace with your ERD image path
    flowchart: "images/flowchart.jpeg"        // 👈 Replace with your Flowchart image path
};
// ============================================================

// ---- Load images from configured paths ----
function loadImages() {
    const usecaseImg = document.getElementById('usecaseImg');
    const erdImg = document.getElementById('erdImg');
    const flowchartImg = document.getElementById('flowchartImg');
    
    if (usecaseImg) usecaseImg.src = imagePaths.usecase;
    if (erdImg) erdImg.src = imagePaths.erd;
    if (flowchartImg) flowchartImg.src = imagePaths.flowchart;
}

// ---- CRUD for Lost Items ----
let lostItems = [
    { id: 1, name: 'Laptop', category: 'Electronics', location: 'Library', status: 'Pending' },
    { id: 2, name: 'Student ID', category: 'Documents', location: 'Gym', status: 'Returned' }
];
let nextLostId = 3;

function renderLost() {
    const tbody = document.getElementById('lostTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    lostItems.forEach(item => {
        const row = tbody.insertRow();
        row.insertCell(0).innerText = item.id;
        row.insertCell(1).innerText = item.name;
        row.insertCell(2).innerText = item.category;
        row.insertCell(3).innerText = item.location;
        row.insertCell(4).innerText = item.status;
        const cell = row.insertCell(5);
        
        const editBtn = document.createElement('button');
        editBtn.className = 'btn-outline btn-sm';
        editBtn.innerHTML = '<i class="fas fa-edit"></i> Edit';
        editBtn.onclick = () => {
            const newName = prompt('Edit name', item.name);
            const newCat = prompt('Category', item.category);
            if (newName && newCat) {
                item.name = newName;
                item.category = newCat;
                renderLost();
            }
        };
        
        const delBtn = document.createElement('button');
        delBtn.className = 'btn-danger btn-sm';
        delBtn.innerHTML = '<i class="fas fa-trash"></i> Delete';
        delBtn.onclick = () => {
            if (confirm('Delete lost item?')) {
                lostItems = lostItems.filter(i => i.id !== item.id);
                renderLost();
            }
        };
        
        cell.appendChild(editBtn);
        cell.appendChild(delBtn);
    });
}

// ---- CRUD for Found Items ----
let foundItems = [
    { id: 1, name: 'Laptop', category: 'Electronics', location: 'Library', status: 'Open' },
    { id: 2, name: 'Water Bottle', category: 'Personal', location: 'Cafeteria', status: 'Open' }
];
let nextFoundId = 3;

function renderFound() {
    const tbody = document.getElementById('foundTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    foundItems.forEach(item => {
        const row = tbody.insertRow();
        row.insertCell(0).innerText = item.id;
        row.insertCell(1).innerText = item.name;
        row.insertCell(2).innerText = item.category;
        row.insertCell(3).innerText = item.location;
        row.insertCell(4).innerText = item.status;
        const cell = row.insertCell(5);
        
        const editBtn = document.createElement('button');
        editBtn.className = 'btn-outline btn-sm';
        editBtn.innerHTML = '<i class="fas fa-edit"></i> Edit';
        editBtn.onclick = () => {
            const newName = prompt('Edit name', item.name);
            if (newName) item.name = newName;
            renderFound();
        };
        
        const delBtn = document.createElement('button');
        delBtn.className = 'btn-danger btn-sm';
        delBtn.innerHTML = '<i class="fas fa-trash"></i> Delete';
        delBtn.onclick = () => {
            if (confirm('Delete found item?')) {
                foundItems = foundItems.filter(f => f.id !== item.id);
                renderFound();
            }
        };
        
        cell.appendChild(editBtn);
        cell.appendChild(delBtn);
    });
}

// ---- Dashboard Charts ----
let categoryChart, trendChart;
function initCharts() {
    const ctxCat = document.getElementById('categoryChart')?.getContext('2d');
    const ctxTrend = document.getElementById('trendChart')?.getContext('2d');
    
    if (ctxCat) {
        categoryChart = new Chart(ctxCat, {
            type: 'bar',
            data: {
                labels: ['Electronics', 'Documents', 'Personal', 'Books'],
                datasets: [{ label: 'Reported Lost', data: [22, 14, 9, 7], backgroundColor: '#1b7e6b', borderRadius: 8 }]
            },
            options: { responsive: true, maintainAspectRatio: true }
        });
    }
    
    if (ctxTrend) {
        trendChart = new Chart(ctxTrend, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
                datasets: [{ label: 'Return Rate %', data: [55, 60, 62, 67, 68], borderColor: '#c3423f', tension: 0.3, fill: false }]
            },
            options: { responsive: true }
        });
    }
}

// ---- Tab switching ----
const tabs = document.querySelectorAll('.tab-btn');
const panes = document.querySelectorAll('.tab-pane');

function switchTab(tabId) {
    panes.forEach(p => p.classList.remove('active-pane'));
    const activePane = document.getElementById(`${tabId}Pane`);
    if (activePane) activePane.classList.add('active-pane');
    
    tabs.forEach(btn => btn.classList.remove('active'));
    const activeBtn = Array.from(tabs).find(btn => btn.dataset.tab === tabId);
    if (activeBtn) activeBtn.classList.add('active');
    
    if (tabId === 'dashboard') {
        setTimeout(() => {
            if (categoryChart) categoryChart.resize();
            if (trendChart) trendChart.resize();
        }, 100);
    }
}

tabs.forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});

// ---- Event Listeners for CRUD buttons ----
document.addEventListener('DOMContentLoaded', () => {
    // Load images from config
    loadImages();
    
    // Lost item add
    const addLostBtn = document.getElementById('addLostBtn');
    if (addLostBtn) {
        addLostBtn.addEventListener('click', () => {
            const name = document.getElementById('lostName').value.trim();
            const cat = document.getElementById('lostCat').value;
            const loc = document.getElementById('lostLoc').value.trim();
            if (name && loc) {
                lostItems.push({ id: nextLostId++, name, category: cat, location: loc, status: 'Pending' });
                renderLost();
                document.getElementById('lostName').value = '';
                document.getElementById('lostLoc').value = '';
                alert('Lost item reported.');
            } else {
                alert('Please fill item name and location');
            }
        });
    }
    
    // Found item add
    const addFoundBtn = document.getElementById('addFoundBtn');
    if (addFoundBtn) {
        addFoundBtn.addEventListener('click', () => {
            const name = document.getElementById('foundName').value.trim();
            const cat = document.getElementById('foundCat').value;
            const loc = document.getElementById('foundLoc').value.trim();
            if (name && loc) {
                foundItems.push({ id: nextFoundId++, name, category: cat, location: loc, status: 'Open' });
                renderFound();
                document.getElementById('foundName').value = '';
                document.getElementById('foundLoc').value = '';
                alert('Found item posted.');
            } else {
                alert('Please fill item name and location');
            }
        });
    }
    
    // Initial render
    renderLost();
    renderFound();
    initCharts();
});